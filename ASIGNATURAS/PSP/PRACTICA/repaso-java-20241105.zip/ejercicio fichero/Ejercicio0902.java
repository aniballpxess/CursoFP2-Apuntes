
package ejercicio0902;

import java.io.*;
import java.util.Scanner;


public class Ejercicio0902 {


    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Nombre del fichero: ");
        String nfichero = sc.nextLine();
        
        File f = new File(nfichero);
        if (f.exists())
        {
            BufferedReader br = null;
            try
            {
                br = new BufferedReader(new FileReader(f));
                String linea = br.readLine();
                while (linea!=null)
                {
                    System.out.println(linea);
                    linea = br.readLine();
                }
            }
            catch (IOException e)
            {
                System.out.println("Error");
            }
            finally
            {
                try
                {
                    if (br!=null)
                        br.close();
                }
                catch (IOException e)
                {
                    System.out.println("Error cerrando el fichero");
                }
            }
            
            
        }
        else
        {
            System.out.println("El fichero "+nfichero+" no existe");
        }
    }
    
}
