package ejercicio0903;

import java.io.*;
import java.util.Scanner;

public class Ejercicio0903 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BufferedReader br = null;
        BufferedWriter bw = null;
        System.out.print("Fichero de entrada: ");
        String fIn = sc.nextLine();
        File f = new File(fIn);
        while (!f.exists())
        {
            System.out.print("El fichero no existe, escribe otro: ");
            fIn = sc.nextLine();
            f = new File(fIn);
        }
        System.out.print("Fichero de salida: ");
        String fOut = sc.nextLine();
        try
        {
            br = new BufferedReader(new FileReader(fIn));
            bw = new BufferedWriter(new FileWriter(fOut));
            String linea = br.readLine();
            while (linea != null)
            {
                bw.write(linea.toUpperCase()+"\n");
                linea = br.readLine();
            }
        }
        catch (IOException e)
        {
            System.out.println("Error en los ficheros.\n "+e.getMessage());
        }
        finally
        {
            try
            {
                if (bw!=null)
                    bw.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero de escritura");
            }
            try
            {
                if (br!=null)
                    br.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero de lectura");
            }
        }
        
        
    }
    
}
