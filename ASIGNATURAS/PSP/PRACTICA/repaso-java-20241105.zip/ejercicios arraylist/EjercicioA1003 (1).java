/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioa1003;

import java.util.*;



public class EjercicioA1003 {

    public static ArrayList<Integer> leerValores()
    {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> lista = new ArrayList<Integer>();
        int n = 0;
        System.out.println("Escribe números enteros. Termina con -99");
        while (n!=-99)
        {
            try
            {
                n = sc.nextInt();
                if (n!=-99)
                    lista.add(n);
            }
            catch (InputMismatchException e)
            {
                sc.nextLine();
            }
        }
        return lista;
    }
    
    public static int calcularSuma(ArrayList<Integer> l)
    {
        Iterator<Integer> it = l.iterator();
        int suma = 0;
        while(it.hasNext())
        {
            suma+=it.next();
        }
        return suma;
    }
    
    public static void mostrarResultados(ArrayList<Integer> l, int s, int m)
    {
        int sup = 0;
        for (int i = 0; i < l.size(); i++)
        {
            if (l.get(i) > m)
                sup++;
            System.out.println("Valor "+(i+1)+": "+l.get(i));
        }
        System.out.println("Suma: "+s);
        System.out.println("Media: "+m);
        System.out.println("Superiores a la media: "+sup);
    }
    
    public static void main(String[] args) {
        
        try
        {
            ArrayList<Integer> l = leerValores();
            int suma = calcularSuma(l);
            int media = suma / l.size();
            mostrarResultados(l, suma, media);
        }
        catch (ArithmeticException e)
        {
            System.out.println("No hay elementos en la lista");
        }
    }
    
}
