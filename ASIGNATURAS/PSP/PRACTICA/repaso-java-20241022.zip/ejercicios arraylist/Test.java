/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioa1001;

import java.util.Scanner;

public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ListaCantantesFamosos lista = new ListaCantantesFamosos();
        
        System.out.println("Escribe el nombre de un cantante");
        lista.anadir(sc.nextLine());
        System.out.println("Escribe el nombre de otro cantante");
        lista.anadir(sc.nextLine());
        
        System.out.println(lista);
        
    }
    
}
