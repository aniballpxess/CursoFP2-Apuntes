
package ejercicio0702;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio0702 {


    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int[] a = null;
        System.out.println("Indica el tamaño del array");
        while (a==null)
        {
            try
            {
                int n = sc.nextInt();
                a = new int[n];
            }
            catch (Exception e)
            {
                System.out.println("Valor incorrecto, escríbalo de nuevo");
                sc.nextLine();
            }
        }
        
        int i = 0;
        while (i < a.length)
        {
            try
            {
                System.out.println ("Valor "+(i+1));
                a[i] = sc.nextInt();
                i++;
            }
            catch (Exception e)
            {
                System.out.println("Número inválido");
                sc.nextLine();
            }
        }
        
        int p = -1;
        while (p!=0)
        {
            try
            {
                System.out.print("Posición: ");
                p = sc.nextInt();
                if (p!=0)
                    System.out.println("El valor es "+a[p-1]);
            }
            catch (InputMismatchException e)
            {
                System.out.println("Número inválido");
                sc.nextLine();
            }
            catch (IndexOutOfBoundsException e)
            {
                System.out.println("Posición no válida");
            }
        }
               
    }
    
}
