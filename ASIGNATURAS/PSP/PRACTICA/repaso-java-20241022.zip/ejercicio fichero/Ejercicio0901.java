
package ejercicio0901;

import java.io.*;
import java.util.Scanner;


public class Ejercicio0901 {


    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe frases. Termina con \"fin\"");
        String frase = sc.nextLine();
        
        String f = "fichero.txt";
        BufferedWriter bw=null;
        
        try
        {
            bw = new BufferedWriter(new FileWriter(f));
            while (!frase.equalsIgnoreCase("FIN"))
            {
                bw.write(frase);
                bw.newLine();
                frase = sc.nextLine();
            }
            bw.close();
        }
        catch (IOException e)
        {
            System.out.println("Error en el fichero");
        }
        finally
        {
            try
            {
                if (bw!=null)
                    bw.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero");
            }
        }
        
    }
    
}
