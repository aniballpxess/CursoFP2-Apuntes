
public class Sumador {

	public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("No has introducido nada");
		}
		else {
			int primer_numero = Integer.parseInt(args[0]);
			int segundo_numero = Integer.parseInt(args[1]);
			int suma_total = 0;
			for (int i = primer_numero; i <= segundo_numero; i++) {
				suma_total += i;
			}
	
			System.out.println("La suma total de los numeros pasados por el argumento es de -->" + suma_total);
		}
	}

}
