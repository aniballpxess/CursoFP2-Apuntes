package ud1.I_EjerciciosUD1.ej1;

import java.util.Scanner;

public class SumadorHijo {

	public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			int num1=sc.nextInt();
			int num2=sc.nextInt();
			if(num2<num1) {
				int reserva=num1;
				num1=num2;
				num2=reserva;
			}
			int sumatotal=0;
			for(int i =num1;i<=num2;i++) {
				sumatotal+=i;
			}
			System.out.println("La suma total de los dos numeros y todos los que haya entre ellos es: "+sumatotal);
			sc.close();
		}

}
