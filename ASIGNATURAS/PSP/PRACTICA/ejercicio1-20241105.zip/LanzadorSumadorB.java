package ud1.I_EjerciciosUD1.ej1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class LanzadorSumador {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		InputStream is=null;
		InputStreamReader isr=null;
		BufferedReader reader=null;
		OutputStream os=null;
		OutputStreamWriter osw=null;
		PrintWriter writer=null;
		try {
			Process proceso=new ProcessBuilder(args).start();
			//Output desde el main
			
			os= proceso.getOutputStream();
			osw=new OutputStreamWriter(os);
			writer= new PrintWriter(osw);
			System.out.println("Introduce primer numero");
			int x=sc.nextInt();			
			writer.println(x);
			System.out.println("Introduce segundo numero");
			int y=sc.nextInt();
			writer.println(y);
			writer.close();
			osw.close();
			os.close();
			//Input al main
			is=proceso.getInputStream();
			isr=new InputStreamReader(is);
			reader=new BufferedReader(isr);
			String linea;
			while((linea=reader.readLine())!=null) {
				System.out.println(linea);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {

				reader.close();
				isr.close();
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		sc.close();
	}

}
