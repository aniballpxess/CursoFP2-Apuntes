package ejercicio2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class LanzadorDivisoresB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ProcessBuilder pb=new ProcessBuilder(args);
			Process proceso=pb.start();
			
			//Leemos por teclado (entrada est�ndar) el valor que pasaremos al hijo
			Scanner sc=new Scanner(System.in);
			int x=sc.nextInt();
			
			//Paso ese valor al hijo. Para ello conecto la entrada est�ndar del padre a trav�s de su flujo de salida, con la entrada est�ndar del hijo (System.in)
			OutputStream os=proceso.getOutputStream();
			OutputStreamWriter osw=new OutputStreamWriter(os);

			//Una vez conectado, le pasamos el valor

			PrintWriter pw=new PrintWriter(osw);
			pw.print(x);
			

			pw.close();
			osw.close();
			os.close();
			
			//Recojo la informaci�n del hijo. Es decir, lo que tenga puesto el hijo con System.out
			InputStream is=proceso.getInputStream();
			InputStreamReader isr=new InputStreamReader(is);
			BufferedReader br=new BufferedReader(isr);
			
			String linea=br.readLine();
			while(linea!=null) {
				System.out.println(linea);
				linea=br.readLine();
			}
			br.close();	
			isr.close();
			is.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
