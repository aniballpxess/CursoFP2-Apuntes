package ejercicio2;

import java.util.Scanner;

public class DivisoresBidir {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x, cont=0;
		//System.out.println("Dame un valor:");
		Scanner sc=new Scanner(System.in);
		x=sc.nextInt();
		
		for(int i=1;i<=x;i++) {
			if(x%i==0) {
				cont++;
			}
		}
		System.out.println("El n�mero de divisores de "+x+" es "+cont);
		
	}

}
