package ud1.I_EjerciciosUD1.ej3;

import java.util.Random;

public class HijoAleatorios {

	public static void main(String[] args) {
		//Genero el Numero aleatorio al mismo tiempo que hago Syso de �l
		System.out.println(new Random().nextInt(11));		
	}

}