package ud1.I_EjerciciosUD1.ej3;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class PadreAleatorios {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try {
			String entrada="";
			while (entrada!=null) {
				Process process = new ProcessBuilder(args).start();
				InputStream is = process.getInputStream();
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);
				String line;
				line = br.readLine();
				System.out.println("Numero Aleatorio: "+line);	
				br.close();
				System.out.print("Introduzca Enter para generar otro\no FIN para terminar: ");
				entrada=sc.nextLine();
				if (entrada.equals("fin")) {
					entrada=null;
					process.destroy();
				}
				br.close();
				isr.close();
				is.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		sc.close();
	}

}
