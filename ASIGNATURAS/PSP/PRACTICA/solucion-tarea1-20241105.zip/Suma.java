package tarea1;


public class Suma {
	
	public void sumar(int n1, int n2){ 
	
	int resultado=n1+n2;
	
	System.out.println (resultado);
	}
	
	public static void main(String[] args){ 
		Suma s=new Suma();
		int n1=Integer.parseInt(args[0]); 
		int n2=Integer.parseInt(args[1]); 
		s.sumar(n1, n2);
		}
	
}
