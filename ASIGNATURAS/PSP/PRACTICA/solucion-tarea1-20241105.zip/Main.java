package tarea1;

import java.io.IOException;
import java.util.Scanner;

public class Main 
{
	

	private static Scanner sc;

	public static void main(String[] args) throws IOException
	{ 

	    final int NUM_PROCESOS=Integer.parseInt(args[0]);
	    final String PREFIJO_FICHEROS=" P1resultado";
	    final String PREFIJO_ERROR=" P1error";
	    Lanzador l= new Lanzador();
	    sc = new Scanner(System.in);
	    for (int i=1;i<=NUM_PROCESOS; i++){
	    	 System.out.println(i + " Lanzamiento");
	    	 System.out.println("introduzca el primer numero");
	         Integer n1 = sc.nextInt();
	         System.out.println("introduzca el segundo numero");
	         Integer n2 = sc.nextInt();
	         l.lanzarSuma(n1, n2, PREFIJO_FICHEROS+String.valueOf(i),PREFIJO_ERROR+String.valueOf(i)); 
	    	}

	 	    System.out.println("Ok");
	}

}
