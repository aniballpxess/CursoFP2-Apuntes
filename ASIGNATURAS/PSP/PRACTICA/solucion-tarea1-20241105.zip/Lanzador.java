package tarea1;

import java.io.File;

public class Lanzador { 
	
public void lanzarSuma(Integer n1, Integer n2, String fichResultado,String fichError)
{ 
	
	String clase="tarea1.Suma"; 
	ProcessBuilder pb;
    try {
    pb = new ProcessBuilder("java",clase, n1.toString(), n2.toString());
    pb.directory(new File("C:\\Users\\laura\\eclipse-workspace\\PSP\\bin\\")); 
    //"C:\Users\laura\eclipse-workspace"
    pb.redirectError(new File("C:\\Users\\laura\\eclipse-workspace\\"+fichError+".txt")); 
    pb.redirectOutput(new File("C:\\Users\\laura\\eclipse-workspace\\"+fichResultado+".txt")); 
    pb.start();
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}

}
