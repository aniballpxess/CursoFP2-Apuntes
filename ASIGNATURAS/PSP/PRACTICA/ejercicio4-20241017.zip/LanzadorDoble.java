package ud1.I_EjerciciosUD1.ej4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class LanzadorDoble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Process proceso;
		Scanner sc=new Scanner(System.in);
		try {
			proceso = new ProcessBuilder(args).start();
			int x=sc.nextInt();
			
			OutputStream os=proceso.getOutputStream();
			OutputStreamWriter osw=new OutputStreamWriter(os);
			PrintWriter pw=new PrintWriter(osw);
			
			
			pw.print(x);
			//pw.flush();
			pw.close();
			osw.close();
			os.close();
			
			InputStream is=proceso.getInputStream();
			InputStreamReader isr=new InputStreamReader(is);
			BufferedReader br=new BufferedReader(isr);
			
			String linea=br.readLine();
			while(linea!=null) {
				System.out.println(linea);
				linea=br.readLine();
			}
			
			br.close();
			isr.close();
			is.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
		
		}
		


	}

}
