package ud1.I_EjerciciosUD1.ej4;

import java.util.Scanner;

public class Doble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Dame un n�mero");
		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		
		System.out.println("El doble de "+x+" es "+2*x);

	}

}
