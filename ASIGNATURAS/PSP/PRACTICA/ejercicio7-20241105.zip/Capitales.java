package ejercicio7;

import java.util.Scanner;

public class Capitales {
	public static void main(String[] args) {
		String pais="", capital="";
		Scanner sc=new Scanner(System.in);
		pais=sc.nextLine();
		switch(pais) {
		case "Espania": 
			capital="Madrid";
			break;
		case "Francia": 
			capital="Paris";
			break;
		case "Italia": 
			capital="Roma";
			break;
			default :	System.out.println("no esta en la bbdd");
		}
		System.out.println(capital);
	}
}
