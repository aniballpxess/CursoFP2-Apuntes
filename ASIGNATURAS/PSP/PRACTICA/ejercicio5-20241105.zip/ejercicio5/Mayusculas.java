package ud1.I_EjerciciosUD1.ej5;

import java.util.Scanner;

public class Mayusculas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String cadena;

		cadena=sc.nextLine();
		cadena=cadena.toUpperCase();
		System.out.println(cadena);
	}

}
