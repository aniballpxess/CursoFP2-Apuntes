package pm.pruebas.mcproyecto;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;

public class HomeActivity extends MainActivity {

    private ImageView animatedPresent;
    private ObjectAnimator shakeAnimator;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        animatedPresent = findViewById(R.id.ib_animatedPresent);

        animatedPresent.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, FormActivity.class);
            startActivity(intent);
        });

        setAnimation();
    }

    private void setAnimation()
    {
        // Configurar animación
        shakeAnimator = ObjectAnimator.ofPropertyValuesHolder(
            animatedPresent,
            PropertyValuesHolder.ofFloat("rotation", -10f, 10f)
        );
        shakeAnimator.setDuration(320);
        shakeAnimator.setRepeatCount(ValueAnimator.INFINITE);
        shakeAnimator.setRepeatMode(ObjectAnimator.REVERSE);
        // Iniciar animación
        shakeAnimator.start();
    }
}